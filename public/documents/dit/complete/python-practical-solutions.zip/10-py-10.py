# Print the first ten natural numbers with both loops
# Environment: Python 3 console
by_for = []
for n in range(1, 11):
    by_for.append(n)
by_while = []
n = 1
while n <= 10:
    by_while.append(n)
    n += 1
print(by_for)
print(by_while)
assert by_for == by_while
