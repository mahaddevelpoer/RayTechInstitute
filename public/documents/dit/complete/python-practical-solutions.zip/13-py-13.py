# Generate a multiplication table
# Environment: Python 3 console
number = int(input())
rows_for = []
for multiplier in range(1, 11):
    rows_for.append(f"{number} x {multiplier} = {number * multiplier}")
rows_while = []
multiplier = 1
while multiplier <= 10:
    rows_while.append(f"{number} x {multiplier} = {number * multiplier}")
    multiplier += 1
assert rows_for == rows_while
print("\n".join(rows_for))
