# Sum 1 through n with two loop forms
# Environment: Python 3 console
n = int(input())
if n < 0:
    print("Invalid integer")
else:
    total_for = 0
    for value in range(1, n + 1):
        total_for += value
    total_while = 0
    value = 1
    while value <= n:
        total_while += value
        value += 1
    print(total_for, total_while)
