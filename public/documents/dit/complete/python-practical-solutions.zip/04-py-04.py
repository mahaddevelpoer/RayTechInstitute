# Count letters, digits and other characters
# Environment: Python 3 console
text = "P@#yn26at^&i5ve"
letters = sum(ch.isalpha() for ch in text)
digits = sum(ch.isdigit() for ch in text)
other = len(text) - letters - digits
print(letters, digits, other)
assert letters + digits + other == len(text)
