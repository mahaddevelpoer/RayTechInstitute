# Return the sum of two arguments
# Environment: Python 3 console
def add(first, second):
    return first + second

print(add(9, 4))
assert add(-2, 2) == 0
