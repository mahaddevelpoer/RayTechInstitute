# Copy fruit values to updatedList
# Environment: Python 3 console
fruits = ["Mango", "Apple", "Banana", "Melon", "Grapes"]
updatedList = []
for fruit in fruits:
    updatedList.append(fruit)
print(updatedList)
assert updatedList == fruits and updatedList is not fruits
