# Display the first console message
# Environment: Python 3 console
print("Hello World!!")
