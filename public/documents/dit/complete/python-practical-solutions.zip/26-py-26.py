# Draw a rectangle
# Environment: desktop-turtle
import turtle
pen = turtle.Turtle()
for length in [120, 80, 120, 80]:
    pen.forward(length)
    pen.right(90)
turtle.done()
