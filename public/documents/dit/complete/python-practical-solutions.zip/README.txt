RayTech Institute DIT Semester 1 Python practical solutions

The official printed list contains numbered tasks 1-29. Its earlier 25-31 reference does not supply extra tasks 30/31.
Run code in a new practice folder using Python 3. GUI tasks 25-29 require desktop Turtle/Tk. The additional Excel example requires pandas and openpyxl; it refuses to overwrite an existing practice workbook.
These are original educational solutions, not authenticated past-paper answers. Headless geometry checks do not claim actual GUI execution. Windows/Office/network installation changes are not performed by this archive.
