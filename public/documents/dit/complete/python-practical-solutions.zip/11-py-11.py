# Calculate factorial with for and while
# Environment: Python 3 console
n = int(input())
if n < 0:
    print("Invalid integer")
else:
    first = 1
    for value in range(1, n + 1):
        first *= value
    second = 1
    value = 1
    while value <= n:
        second *= value
        value += 1
    print(first, second)
