# Test divisibility by seven
# Environment: Python 3 console
try:
    number = int(input())
except ValueError:
    print("Invalid integer")
else:
    print("Divisible by 7" if number % 7 == 0 else "Not divisible by 7")
