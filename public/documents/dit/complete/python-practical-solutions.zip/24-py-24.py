# Write a factorial function
# Environment: Python 3 console
def factorial(n):
    if not isinstance(n, int) or isinstance(n, bool) or n < 0:
        raise ValueError("Use a nonnegative integer")
    product = 1
    for value in range(1, n + 1):
        product *= value
    return product

print(factorial(0), factorial(5))
assert factorial(1) == 1
try:
    factorial(-1)
except ValueError:
    pass
else:
    raise AssertionError("Negative value was accepted")
