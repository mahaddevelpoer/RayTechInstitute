# Return supplied values as a list
# Environment: Python 3 console
def collect(*values):
    return list(values)

print(collect(1, "A", 3))
assert collect() == []
