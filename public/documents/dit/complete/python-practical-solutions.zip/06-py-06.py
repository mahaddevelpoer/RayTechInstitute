# Split hyphen-separated text
# Environment: Python 3 console
text = "Bareera-is-a-data-scientist"
for part in text.split("-"):
    print(part)
