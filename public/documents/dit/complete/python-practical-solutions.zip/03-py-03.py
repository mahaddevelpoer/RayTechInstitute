# Calculate a circle area
# Environment: Python 3 console
import math
radius = float(input())
if radius < 0:
    print("Invalid radius")
else:
    area = math.pi * radius ** 2
    print(f"{area:.2f}")
