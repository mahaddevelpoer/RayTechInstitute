# Display a list in reverse order
# Environment: Python 3 console
values = [10, 20, 30]
print(values[::-1])
assert values == [10, 20, 30]
