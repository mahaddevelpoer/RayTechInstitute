# Square every item
# Environment: Python 3 console
numbers = [2, 4, 6, 6, 10]
squared = [number ** 2 for number in numbers]
print(squared)
