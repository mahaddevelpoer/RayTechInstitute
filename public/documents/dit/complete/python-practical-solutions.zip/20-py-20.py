# Find names beginning with B
# Environment: Python 3 console
names = ["Ali", "Shayan", "Baqir", "Bareera", "Zulfiqar"]
selected = []
for name in names:
    if name.startswith("B"):
        selected.append(name)
print(selected)
