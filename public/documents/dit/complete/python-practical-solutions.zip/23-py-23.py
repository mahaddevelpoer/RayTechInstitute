# Return multiple computed values
# Environment: Python 3 console
def calculate(first, second):
    return first + second, first - second

sum_value, difference = calculate(9, 4)
print(sum_value, difference)
