# Draw a square
# Environment: desktop-turtle
import turtle
pen = turtle.Turtle()
for _ in range(4):
    pen.forward(80)
    pen.right(90)
turtle.done()
