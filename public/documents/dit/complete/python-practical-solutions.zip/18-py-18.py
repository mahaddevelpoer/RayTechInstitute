# Replace the supplied value 20
# Environment: Python 3 console
values = [22, 12, 25, 667, 988, 387, 20, 188, 77]
if 20 in values:
    values[values.index(20)] = 200
print(values)
