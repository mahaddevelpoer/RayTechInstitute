# Find a name without case sensitivity
# Environment: Python 3 console
text = "Baqir is student of python programming class. Baqir belongs to district peshawar"
print(text.casefold().count("baqir".casefold()))
