# Read and display five fruit names
# Environment: Python 3 console
fruits = []
for _ in range(5):
    fruits.append(input().strip())
for fruit in fruits:
    print(fruit)
