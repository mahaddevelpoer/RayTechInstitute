# Draw a circle
# Environment: desktop-turtle
import turtle
pen = turtle.Turtle()
pen.circle(50)
turtle.done()
