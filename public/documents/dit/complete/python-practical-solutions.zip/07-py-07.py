# Classify an integer as even or odd
# Environment: Python 3 console
try:
    number = int(input())
except ValueError:
    print("Invalid integer")
else:
    print("Even" if number % 2 == 0 else "Odd")
