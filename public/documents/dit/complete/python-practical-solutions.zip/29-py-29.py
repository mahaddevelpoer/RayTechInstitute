# Draw separate lines
# Environment: desktop-turtle
import turtle
pen = turtle.Turtle()
pen.forward(100)
pen.penup()
pen.goto(0, -40)
pen.pendown()
pen.back(80)
turtle.done()
