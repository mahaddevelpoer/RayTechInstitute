# Calculate the mean of three bills
# Environment: Python 3 console
bills = [23000, 32000, 64000]
mean = sum(bills) / len(bills)
print(f"{mean:.2f}")
assert sum(bills) == 119000
