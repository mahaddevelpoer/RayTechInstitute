# Check a requested name
# Environment: Python 3 console
names = ["Pakistan", "Shayan", "Baqir", "GCMS"]
requested = input().strip()
print("Present" if requested in names else "Absent")
