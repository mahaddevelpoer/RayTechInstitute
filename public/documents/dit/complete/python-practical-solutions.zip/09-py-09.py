# Classify the exercise score
# Environment: Python 3 console
try:
    score = int(input())
except ValueError:
    print("Invalid score")
else:
    if not 1 <= score <= 100:
        print("Invalid score")
    elif score <= 50:
        print("Average")
    elif score <= 70:
        print("Good")
    else:
        print("Excellent")
