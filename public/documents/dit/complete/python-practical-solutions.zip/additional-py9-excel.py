# Write and read a practice Excel table
# Environment: desktop-excel
import pandas as pd
from pathlib import Path

path = Path("marks-practice.xlsx")
if path.exists():
    raise FileExistsError("Choose a new practice filename")
source = pd.DataFrame({"Name": ["Ali", "Ayesha"], "Marks": [50, 71]})
source.to_excel(path, sheet_name="Marks", index=False, engine="openpyxl")
loaded = pd.read_excel(path, sheet_name="Marks", engine="openpyxl")
assert loaded.columns.tolist() == ["Name", "Marks"]
assert loaded["Name"].tolist() == ["Ali", "Ayesha"]
assert loaded["Marks"].tolist() == [50, 71]
print("Rows:", len(loaded))
print("Total:", loaded["Marks"].sum())
